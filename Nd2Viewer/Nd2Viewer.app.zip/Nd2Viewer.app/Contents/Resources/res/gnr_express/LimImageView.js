import * as THREE from '/res/gnr_express/three/three.module.js';
import { OrbitControls } from '/res/gnr_express/three/addons/OrbitControls.js';

export const ViewingMode = {
    imageView: 0,
    volumeView: 1
};
Object.seal(ViewingMode);

class LimImageViewControl {
    #view
    #target
    #onWheelHandler
    #onPointerDownHandler
    #onPointerMoveHandler
    #onPointerUpHandler

    constructor(view, target) {
        this.#view = view;
        this.#target = target;

        let isPan = false;
        let moveState = null;        
        let panOriginalX = 0, panOriginalY = 0;

        this.#onWheelHandler = (ev) => {
            const delta = -1 * ev.deltaY;
            if (!isPan) {
                this.#view.onWheel(delta, ev.clientX, ev.clientY);
            }
            ev.preventDefault();
        };

        this.#onPointerDownHandler = (ev) => {
            ev.preventDefault();
            isPan = true;
            panOriginalX = ev.screenX;
            panOriginalY = ev.screenY;
            moveState = this.#view.onDragBegin();
        };

        this.#onPointerMoveHandler = (ev) => {
            if (!isPan) return;    
            this.#view.onDragMove(moveState, ev.screenX - panOriginalX, ev.screenY - panOriginalY);
        };

        this.#onPointerUpHandler =() => {
            this.#view.onDragEnd();
            isPan = false;
        };        

        this.#target.addEventListener("wheel", this.#onWheelHandler);
        this.#target.addEventListener("pointerdown", this.#onPointerDownHandler);        
        this.#target.addEventListener("pointermove", this.#onPointerMoveHandler);
        this.#target.addEventListener("pointerup", this.#onPointerUpHandler);
    }

    dispose() {
        this.#target.removeEventListener("wheel", this.#onWheelHandler);
        this.#target.removeEventListener("pointerdown", this.#onPointerDownHandler);        
        this.#target.removeEventListener("pointermove", this.#onPointerMoveHandler);
        this.#target.removeEventListener("pointerup", this.#onPointerUpHandler);
    }
}

export class LimImageView {
    #imageCanvas
    #navigator
    #viewingMode
    #is3d
    #is8bitRgb
    #channelIndex
    #binaryIndexes
    #zoomIndex
    #imageX
    #imageY
    #imageWidth
    #imageHeight
    #imageZoomSizes
    #imageZoomTileCache
    #allChannelNames
    #allChannelColors
    #allChannelGains
    #lutsEnabled
    #showSingleChannelInMono    
    #allBinLayerNames
    #allLoopIndexes
    #allLoopIndexesMax
    #currentLoopIndexes  
    #imageViewControl
    #volumeViewRenderer
    #volumeViewScene
    #volumeViewCamera
    #volumeViewMaterial
    #volumeViewMesh
    #volumeViewControl 
    #setZoomIndexLow
    #setImageModeLow
    #setVolumeModeLow
    #playingLoop    
    #imageTileSize
    #volumeReqPower
    #initialLoopPos
    
    constructor(canvas, navigator) {
        this.#imageCanvas = canvas ?? document.createElement("canvas");
        this.#navigator = navigator ?? createLimNavigator();        
        this.#viewingMode = ViewingMode.imageView;
        this.#is3d = false;
        this.#is8bitRgb = false;    
        this.#channelIndex = -1;
        this.#binaryIndexes = [];
        this.#zoomIndex = 0;
        this.#imageX = 0;
        this.#imageY = 0;
        this.#imageWidth = 0;
        this.#imageHeight = 0;
        this.#imageZoomSizes = [];
        this.#imageZoomTileCache = [];
        this.#allChannelNames = [];
        this.#allChannelColors = [];
        this.#allChannelGains = [];
        this.#allBinLayerNames = [];
        this.#allLoopIndexes = null;
        this.#allLoopIndexesMax = null;
        this.#currentLoopIndexes = null;
        this.#imageViewControl = new LimImageViewControl(this, this.#imageCanvas);
        this.#volumeViewRenderer = null;
        this.#volumeViewScene = null;
        this.#volumeViewCamera = null;
        this.#volumeViewMaterial = null;
        this.#volumeViewMesh = null;
        this.#volumeViewControl = null;
        this.#playingLoop = "";
        this.#imageTileSize = 256;
        this.#volumeReqPower = 9;
        this.#initialLoopPos = {};
       
        this.#setZoomIndexLow = (value, mouseX, mouseY) => {
            if (this.#zoomIndex === value || this.#imageZoomSizes?.[value] == undefined)
                return;
            const oldZoomIndex = this.#zoomIndex;
            this.#zoomIndex = value;
            this?.onzoomindexchanged?.();
            if (this.#viewingMode === ViewingMode.imageView)     
                this.updateImage(oldZoomIndex, mouseX, mouseY);
        }

        this.#setImageModeLow = () => {
            let parent = null;
            if (this.#volumeViewRenderer && (parent = this.#volumeViewRenderer.domElement.parentElement)) {
                parent.replaceChild(this.#imageCanvas, this.#volumeViewRenderer.domElement);
            }
            this.#imageCanvas.style.display = "block";
            this.#imageCanvas.style.userSelect = "none";

            this.#volumeViewRenderer?.dispose?.();
            this.#volumeViewRenderer = null;
            this.#volumeViewScene?.dispose?.();
            this.#volumeViewScene = null;
            this.#volumeViewCamera?.dispose?.();
            this.#volumeViewCamera = null;
            this.#volumeViewMaterial?.dispose?.();
            this.#volumeViewMaterial = null;
            this.#volumeViewMesh?.dispose?.();
            this.#volumeViewMesh = null;
            this.#volumeViewControl?.dispose?.();
            this.#volumeViewControl = null;

            this.#imageViewControl = new LimImageViewControl(this, this.#imageCanvas);
            this.clearCanvas();
            this.updateImage();

            const znavtrack = document.getElementById("ndnav-track-z");
            if (znavtrack)
                znavtrack.classList.remove('lim-disabled');
            const znavctrl = document.getElementById("ndnav-ctrl-z");
            if (znavctrl)
                znavctrl.classList.remove('lim-disabled');    
            const znavlabel = document.getElementById("ndnav-label-z");
            if (znavlabel && znavtrack)
                znavlabel.innerText = `Z-slice ${this.#currentLoopIndexes["z"]+1}/${znavtrack.alltickscount}`;
        }

        this.#setVolumeModeLow = () => {
            this.clearCache();
            this.#imageViewControl?.dispose?.();
            this.#imageViewControl = null;

            this.#volumeViewScene = new THREE.Scene();
            this.#volumeViewRenderer = new THREE.WebGLRenderer({ preserveDrawingBuffer: true });        
            this.#volumeViewRenderer.setPixelRatio(window.devicePixelRatio); 
            this.#volumeViewRenderer.setSize(this.#imageCanvas.width, this.#imageCanvas.height);
            this.#imageCanvas.style.display = "block";
            this.#imageCanvas.style.userSelect = "none";
            
            const h = 512;
            const aspect = this.#imageCanvas.width / this.#imageCanvas.height;
            this.#volumeViewCamera = new THREE.OrthographicCamera(-h * aspect / 2, h * aspect / 2, h / 2, -h / 2, 1, 2000);
            this.#volumeViewCamera.position.set(-160, -160, 160);
            this.#volumeViewCamera.up.set(0, 0, 1);

            this.#volumeViewControl = new OrbitControls(this.#volumeViewCamera, this.#volumeViewRenderer.domElement);
            this.#volumeViewControl.addEventListener('change', () => { this.renderVolume(); });
            this.#volumeViewControl.minZoom = 0.25;
            this.#volumeViewControl.maxZoom = 8.0;
            this.#volumeViewControl.enablePan = true;

            let parent = null;
            if (this.#imageCanvas && (parent = this.#imageCanvas.parentElement)) {
                parent.replaceChild(this.#volumeViewRenderer.domElement, this.#imageCanvas);
            }            

            this.updateVolume();

            const znavtrack = document.getElementById("ndnav-track-z");
            if (znavtrack)
                znavtrack.classList.add('lim-disabled');
            const znavctrl = document.getElementById("ndnav-ctrl-z");
            if (znavctrl)
                znavctrl.classList.add('lim-disabled');            
            const znavlabel = document.getElementById("ndnav-label-z");
            if (znavlabel && znavtrack)
                znavlabel.innerText = `Z-slice all ${znavtrack.alltickscount}`;            
        }

        this.#imageCanvas.style.display = "block";
        this.#imageCanvas.style.userSelect = "none";        
    }

    onWheel(delta, mouseX, mouseY) {
        if (0 < delta && this.#zoomIndex < this.#imageZoomSizes.length-1) {
            this.#setZoomIndexLow(this.#zoomIndex + 1, mouseX, mouseY-40);
        }
        else if (delta < 0 && 0 < this.#zoomIndex) {
            this.#setZoomIndexLow(this.#zoomIndex - 1, mouseX, mouseY-40);
        }
    }

    onDragBegin() {
        return {
            imageX: this.#imageX,
            imageY: this.#imageY,
        };
    }

    onDragMove(originalState, x, y) {
        if (!this.#imageZoomSizes.length)
            return;

        const { s: scale, p: power, w: width, h: height } = this.#imageZoomSizes[this.#zoomIndex];
        let oldX = this.#imageX;
        let oldY = this.#imageY;
        if (this.#imageCanvas.width < width) {
            this.#imageX = originalState.imageX - x/scale;
            this.#imageX = Math.floor(Math.max(0, Math.min(this.#imageX, width-this.#imageCanvas.width)));
        }
        else if (this.#imageCanvas.width < width*scale) {
            const center = (width-this.#imageCanvas.width)/2;
            const margin = (width*scale - this.#imageCanvas.width)/2/scale;
            this.#imageX = Math.floor(Math.max(center-margin, Math.min(originalState.imageX - x/scale, center+margin)));
        }

        if (this.#imageCanvas.height < height) {
            this.#imageY = originalState.imageY - y/scale;
            this.#imageY = Math.floor(Math.max(0, Math.min(this.#imageY, height-this.#imageCanvas.height)));
        }
        else if (this.#imageCanvas.height < height*scale) {
            const center = (height - this.#imageCanvas.height)/2;
            const margin = (height*scale - this.#imageCanvas.height)/2/scale;
            this.#imageY = Math.floor(Math.max(center-margin, Math.min(originalState.imageY - y/scale, center+margin)));
        }

        if (oldX !== this.#imageX || oldY !== this.#imageY) {                
            this.renderImage();
        }        
    }    

    onDragEnd() {
        this.renderImage();
    }

    get currentLoopIndexes() {
        return { ...this.#currentLoopIndexes };
    }    

    set currentLoopIndexes(indexes) {
        if (JSON.stringify(indexes) === JSON.stringify(this.#currentLoopIndexes)) 
            return;

        const keys = new Set([...Object.getOwnPropertyNames(this.#currentLoopIndexes), ...Object.getOwnPropertyNames(indexes)])
        const change = [...keys.values()].filter(k => this.#currentLoopIndexes[k] !== indexes[k]);

        this.#currentLoopIndexes = { ...indexes };
        this?.onCurrentLoopIndexesChanged?.([ ...change ]);
        this.updateNavigator();
        this.clearCache();
        this.update();
    }

    get currentSeqIndex() {
        return 0 < this.#allLoopIndexes.length ? this.#allLoopIndexes.indexOf(JSON.stringify(this.#currentLoopIndexes)) : 0;
    }

    moveCurrentLoopIndex(loop, delta) {
        const loopIndexes = this.currentLoopIndexes;  
        if (!Object.hasOwn(loopIndexes, loop) || (document.getElementById(`ndnav-track-${loop}`)?.classList?.contains?.('lim-disabled') ?? true))
            return false;
        if (delta) {
            loopIndexes[loop] += delta;
        } else {
            loopIndexes[loop] = this.#initialLoopPos[loop];
        }
        if (loopIndexes[loop] < 0 || this.#allLoopIndexesMax[loop] < loopIndexes[loop])
            return false;
        this.currentLoopIndexes = loopIndexes;
        return true;
    }

    bestFit() {
        if (0 <= this.#zoomIndex && this.#zoomIndex < this.#imageZoomSizes.length) {
            const { w: width, h: height } = this.#imageZoomSizes[this.#zoomIndex];
            this.#imageX = Math.floor((width - this.#imageCanvas.width) / 2);
            this.#imageY = Math.floor((height - this.#imageCanvas.height) / 2);
        }

        const diffs = this.#imageCanvas.height <= this.#imageCanvas.width 
            ? this.#imageZoomSizes.map(item => Math.abs(this.#imageCanvas.height - item.h*item.s))
            : this.#imageZoomSizes.map(item => Math.abs(this.#imageCanvas.width  - item.w*item.s ));        

        this.zoomIndex = diffs.indexOf(Math.min(...diffs))
    };

    updateNavigator() {
        const loopIndexes = this.#currentLoopIndexes;
        const ndtitles = { "w": "Well", "m": "Point", "t": "Time", "z": "Z-slice" };
        const ndtracks = this.#navigator.getElementsByClassName("ndnav-dim-track");
        const ndlabels = this.#navigator.getElementsByClassName("ndnav-dim-label");
        for (let i = 0; i < ndtracks.length; i++) {
            const ndtrack = ndtracks[i];
            const curindex = loopIndexes[ndtrack.loop];
            ndlabels[i].innerText = `${ndtitles[ndtrack.loop]} ${curindex+1}/${ndtrack.alltickscount}`;
            for (let seltick of ndtrack.getElementsByClassName("ndnav-tick selected"))
                seltick.classList.remove("selected");
            const ticks = ndtrack.getElementsByClassName("ndnav-tick");
            ticks[Math.floor(curindex * ticks.length / ndtrack.alltickscount)].classList.add("selected");
        }
    }

    updateCanvasSize(w, h) {
        switch (this.#viewingMode) {
            case ViewingMode.imageView:
                this.#imageCanvas.width = w;
                this.#imageCanvas.height = h;
                this.updateImage();
                break;
            case ViewingMode.volumeView:
                if (this.#volumeViewCamera) {
                    this.#volumeViewRenderer.setSize(w, h);
                    const aspect = w / h;
                    const frustumHeight = this.#volumeViewCamera.top - this.#volumeViewCamera.bottom;
                    this.#volumeViewCamera.left = - frustumHeight * aspect / 2;
                    this.#volumeViewCamera.right = frustumHeight * aspect / 2;
                    this.#volumeViewCamera.updateProjectionMatrix();
                    this.renderVolume();
                }
                break;                
        }
    }
    
    clearCanvas(){
        const ctx = this.#imageCanvas.getContext("2d");
        ctx.clearRect(0, 0, this.#imageCanvas.width, this.#imageCanvas.height);
    };
    
    clearCache() {
        if (!this.#imageZoomSizes.length)
            return;
        this.#imageZoomTileCache = [];
        for (let i = 0; i < this.#imageZoomSizes.length; i++) {
            const { w: width, h: height } = this.#imageZoomSizes[i];
            this.#imageZoomTileCache.push(new Array(Math.ceil(width / this.#imageTileSize) * Math.ceil(height / this.#imageTileSize)));
        }
    }

    update() {
        switch (this.#viewingMode) {
            case ViewingMode.imageView:
                this.updateImage();
                break;
            case ViewingMode.volumeView:
                this.updateVolume();
                break;
        }
    }

    async updateImage(fromZoomIndex, mouseX, mouseY) {
        if (!this.#imageZoomSizes.length)    
            return;

        const half_canvas_width = this.#imageCanvas.width / 2;
        const half_canvas_height = this.#imageCanvas.height / 2;
        const from_scale = this.#imageZoomSizes?.[fromZoomIndex]?.s ?? 1.0;
        const { s: scale, w: width, h: height } = this.#imageZoomSizes[this.#zoomIndex];
        if (typeof mouseX === "undefined") {
            mouseX = Math.round(half_canvas_width);
        }
        if (typeof mouseY === "undefined") {
            mouseY = Math.round(half_canvas_height);
        }

        if (width*scale < this.#imageCanvas.width || fromZoomIndex === -1) {
            this.#imageX = Math.floor((width - this.#imageCanvas.width) / 2);                
            mouseX = Math.round(half_canvas_width);
        }
        else if (typeof fromZoomIndex === "number") {
            const srcMouseX = (mouseX - half_canvas_width)/from_scale + half_canvas_width;
            const dstMouseX = (mouseX - half_canvas_width)/scale + half_canvas_width;
            this.#imageX = Math.floor(((this.#imageX + srcMouseX) / this.#imageZoomSizes[fromZoomIndex].w * width) - dstMouseX);
            if (width < this.#imageCanvas.width) {
                const center = (width-this.#imageCanvas.width)/2;
                const margin = (width*scale - this.#imageCanvas.width)/2/scale;
                this.#imageX = Math.floor(Math.max(center-margin, Math.min(this.#imageX, center+margin)));          
            }
            else {
                this.#imageX = Math.floor(Math.max(0, Math.min(this.#imageX, width-this.#imageCanvas.width)));               
            }
        }
    
        if (height*scale < this.#imageCanvas.height || fromZoomIndex === -1) {
            this.#imageY = Math.floor((height - this.#imageCanvas.height) / 2);
            mouseY = Math.round(half_canvas_height);
        }
        else if (typeof fromZoomIndex === "number") {
            const srcMouseY = (mouseY - half_canvas_height)/from_scale + half_canvas_height;
            const dstMouseY = (mouseY - half_canvas_height)/scale + half_canvas_height;
            this.#imageY = Math.floor(((this.#imageY + srcMouseY) / this.#imageZoomSizes[fromZoomIndex].h * height) - dstMouseY);
            if (height < this.#imageCanvas.height) {
                const center = (height - this.#imageCanvas.height)/2;
                const margin = (height*scale - this.#imageCanvas.height)/2/scale;
                this.#imageY = Math.floor(Math.max(center-margin, Math.min(this.#imageY, center+margin)));            
            }
            else {
                this.#imageY = Math.floor(Math.max(0, Math.min(this.#imageY, height-this.#imageCanvas.height)));                
            }
        }
    
        /*if (typeof fromZoomIndex === "number" && 0 <= fromZoomIndex && fromZoomIndex < this.#zoomIndex && scale === 1.0) {
            const dstMouseX = (mouseX - half_canvas_width)/scale + half_canvas_width;
            const dstMouseY = (mouseY - half_canvas_height)/scale + half_canvas_height;
            const xFactor = width / this.#imageZoomSizes[fromZoomIndex].w / from_scale;
            const yFactor = height / this.#imageZoomSizes[fromZoomIndex].h / from_scale;
            let left = Math.floor(mouseX * xFactor - dstMouseX);
            let top = Math.floor(mouseY * yFactor - dstMouseY);
            let im = await createImageBitmap(this.#imageCanvas, { resizeWidth: xFactor*this.#imageCanvas.width, resizeHeight: yFactor*this.#imageCanvas.height });
            const ctx = this.#imageCanvas.getContext("2d");
            ctx.setTransform(1, 0, 0, 1, 0, 0);
            ctx.translate(this.#imageCanvas.width/2, this.#imageCanvas.height/2);
            ctx.scale(scale, scale);        
            ctx.translate(-this.#imageCanvas.width/2, -this.#imageCanvas.height/2);            
            ctx.drawImage(im, -left, -top);
        }*/
    
        this.renderImage();
    }

    async updateVolume() {
        const localNonce = this.updateVolumeNonce = new Object();

        const ch = this.#channelIndex;
        const gains = btoa(JSON.stringify(this.#lutsEnabled ? this.#allChannelGains : this.#allChannelGains.map(() => 1.0)));
        const sel_channel = (typeof ch === "undefined" || ch === -1) ? 'f' : (ch).toString(16);
        const sel_bin_layers = this.#binaryIndexes.reduce((p, c) => p|(1 << c), 0).toString(16);

        if (localNonce !== this.updateVolumeNonce)
            return;

        this?.onLoadProgressChanged?.(0);
        const response = await this.loadVolumeInfo(this.currentSeqIndex, this.#volumeReqPower);
        if (localNonce !== this.updateVolumeNonce)
            return;

        const { xCount, yCount, zCount, slices } = response;
        const [ xSize, ySize, zSize ] = [ xCount, yCount, response.zSize*response.xCount/response.xSize ];

        let u_fmt = 0;
        const volume_format = 'RGBA8';
        const volume_data = new Uint8Array(xCount*yCount*zCount*4);
        const show_in_gray = this.#showSingleChannelInMono && (this.#channelIndex !== -1 || this.#allChannelNames.length === 1);

        const makeScene = async () => {
            const texture = new THREE.Data3DTexture(volume_data, xCount, yCount, zCount);
            if (volume_format === 'RGBA8') {
                u_fmt = 4;
                texture.internalFormat = 'RGBA8';
                texture.format = THREE.RGBAFormat;
                texture.type = THREE.UnsignedByteType;
            }
            else if (volume_format === 'R8') {
                u_fmt = 1;
                texture.internalFormat = 'R8';
                texture.format = THREE.RedFormat;
                texture.type = THREE.UnsignedByteType;
            }
    
            texture.minFilter = THREE.LinearFilter;
            texture.magFilter = THREE.LinearFilter;
            texture.unpackAlignment = 1;
            texture.needsUpdate = true;            
    
            this.#volumeViewControl.target.set(xSize/2, ySize/2, zSize/2);
            this.#volumeViewControl.update();        
    
            if (!this.#volumeViewMaterial) {
           
                this.#volumeViewMaterial = new THREE.RawShaderMaterial( {
                    glslVersion: THREE.GLSL3,
                    uniforms: {
                        u_fmt: { value: u_fmt },
                        u_data: { value: texture },
                        u_gray: { value: show_in_gray ? 1 : 0 },
                        u_size: { value: new THREE.Vector3(xSize, ySize, zSize) },
                        u_count: { value: new THREE.Vector3(xCount, yCount, zCount) },                    
                    },
                    vertexShader,
                    fragmentShader,
                    side: THREE.BackSide,
                });
            
                const geometry = new THREE.BoxGeometry(xSize, ySize, zSize);
                geometry.translate(xSize/2 - 0.5, ySize/2 - 0.5, zSize/2 - 0.5);
            
                this.#volumeViewMesh?.dispose?.();
                this.#volumeViewMesh = new THREE.Mesh(geometry, this.#volumeViewMaterial);
                this.#volumeViewScene.add(this.#volumeViewMesh);
    
    
                const vertices = [];
    
                vertices.push(0, 0, 0, xSize, 0, 0);
                vertices.push(0, 0, 0, 0, ySize, 0);
                vertices.push(0, 0, 0, 0, 0, zSize);
    
                vertices.push(0, 0, zSize, xSize, 0, zSize);
                vertices.push(0, 0, zSize, 0, ySize, zSize);            
    
                vertices.push(xSize, 0, 0, xSize, ySize, 0);
                vertices.push(xSize, 0, 0, xSize, 0, zSize);            
    
                vertices.push(0, ySize, 0, xSize, ySize, 0);
                vertices.push(0, ySize, 0, 0, ySize, zSize);
    
                vertices.push(0, ySize, zSize, xSize, ySize, zSize);
                vertices.push(xSize, 0, zSize, xSize, ySize, zSize);
    
                vertices.push(xSize, ySize, 0, xSize, ySize, zSize);            
    
                const bbg = new THREE.BufferGeometry()
                bbg.setAttribute( 'position', new THREE.Float32BufferAttribute( vertices, 3 ) );
    
                const lineSegments = new THREE.LineSegments(bbg, new THREE.LineDashedMaterial({ color: 0xa0a0a0, depthTest: false, scale: 1, dashSize: 4, gapSize: 2 }));
                lineSegments.computeLineDistances();
                this.#volumeViewScene.add(lineSegments);
    
                this.#volumeViewScene.add(new THREE.LineSegments(bbg, new THREE.LineBasicMaterial( { color: 0xffffff } )));
            }
            else {
                this.#volumeViewMaterial.uniforms['u_fmt'].value = u_fmt;
                this.#volumeViewMaterial.uniforms['u_data'].value = texture;
                this.#volumeViewMaterial.uniforms['u_gray'].value = show_in_gray ? 1 : 0;                
            }
    
            this.renderVolume();
        };

        makeScene();

        await (() => {
            return new Promise((resolve, reject) => {
                let slicesLoaded = 0;
                const allTileImages = [];
                for (let i = 0; i < slices.length; i++) {
                    const slice = slices[i];
                    const tiles = slice.tiles;            
                    const sliceSeqIndex = slice.seqIndex;
                    slice.tilesLoaded = 0;
                    for (let j = 0; j < tiles.length; j++) {
                        if (localNonce !== this.updateVolumeNonce) {
                            allTileImages.forEach(item => item.src = '');
                            return;
                        }

                        const tile = tiles[j];
                        const tileImage = new Image(tile.w, tile.h);
                        allTileImages.push(tileImage);
                        tileImage.addEventListener("load", () => {
                            if (localNonce !== this.updateVolumeNonce) {
                                allTileImages.forEach(item => item.src = '');
                                return;
                            }
                            if (!slice.ctx) {
                                slice.canvas = document.createElement('canvas');
                                slice.canvas.width = xCount; slice.canvas.height = yCount;
                                slice.ctx = slice.canvas.getContext("2d", { willReadFrequently: true });
                            }
                            slice.ctx.drawImage(tileImage, tile.x, tile.y);
                            if (++slice.tilesLoaded == tiles.length) {
                                const img_data = slice.ctx.getImageData(0, 0, xCount, yCount);
                                volume_data.set(img_data.data, i*xCount*yCount*4);
                                slice.ctx = null; slice.canvas = null;
                                if (i % 8 == 7) {
                                    makeScene();          
                                }
                                if (++slicesLoaded == slices.length) {
                                    makeScene();
                                    this.renderVolumeDone(true);
                                }
                                this?.onLoadProgressChanged?.(Math.floor(100 * slicesLoaded / slices.length));                                                                    
                            }
                        });
        
                        tileImage.src = this.loadTile(sliceSeqIndex, this.#volumeReqPower, tile.xTile, tile.yTile, sel_channel, sel_bin_layers, gains);
                    }
                }                
            });
        })();
    }

    checkAndAdvancePlayingLoop() {
        if (this.#playingLoop) {
            const loopIndexes = this.currentLoopIndexes;
            if (++loopIndexes[this.#playingLoop] == (this.#allLoopIndexesMax[this.#playingLoop]+1))
                loopIndexes[this.#playingLoop] = 0;
            this.currentLoopIndexes = loopIndexes;
        }        
    }

    async renderVolumeDone(allTilesWereDrawn) {
        if (allTilesWereDrawn)
            this.checkAndAdvancePlayingLoop();
    }


    loadTile(seqindex, reqpower, x, y, selchannel, selbinlayers, luts) {
    }

    renderImage() {
        if (!this.#imageZoomSizes.length)
            return;

        const localNonce = this.renderImageNonce = new Object();

        let updateCanvasFilter = "none";
        if (this.#showSingleChannelInMono && (this.#channelIndex !== -1 || this.#allChannelNames.length === 1)) {
            const rgba = LimParseHtmlRGBA(this.#allChannelColors[Math.max(0, this.#channelIndex)]);
            const Y = 0.2126 * rgba[0] + 0.7152 * rgba[1] + 0.0722 * rgba[2];
            updateCanvasFilter = `grayscale(100%) brightness(${255/Y*100}%)`;
        }

        const ch = this.#channelIndex;
        const gains = btoa(JSON.stringify(this.#lutsEnabled ? this.#allChannelGains : this.#allChannelGains.map(() => 1.0)));
        const selchannel = (typeof ch === "undefined" || ch === -1) ? 'f' : (ch).toString(16);
        const selbinlayers = this.#binaryIndexes.reduce((p, c) => p|(1 << c), 0).toString(16);
    
        const { s: scale,p: power, w: width, h: height } = this.#imageZoomSizes[this.#zoomIndex];
        const tilesInX = Math.ceil(width / this.#imageTileSize);
    
        const ctx = this.#imageCanvas.getContext("2d");
        ctx.setTransform(1, 0, 0, 1, 0, 0);
        ctx.translate(this.#imageCanvas.width/2, this.#imageCanvas.height/2);
        ctx.scale(scale, scale);        
        ctx.translate(-this.#imageCanvas.width/2, -this.#imageCanvas.height/2);

        if (width*scale < this.#imageCanvas.width) {
            this.#imageX = Math.floor((width - this.#imageCanvas.width) / 2);
            ctx.clearRect(0, 0, -this.#imageX, this.#imageCanvas.height);
            ctx.clearRect(this.#imageX + this.#imageCanvas.width, 0, this.#imageCanvas.width, this.#imageCanvas.height);
        }
        if (height*scale < this.#imageCanvas.height) {
            this.#imageY = Math.floor((height - this.#imageCanvas.height) / 2);
            ctx.clearRect(0, 0, this.#imageCanvas.width, -this.#imageY);
            ctx.clearRect(0, this.#imageY + this.#imageCanvas.height, this.#imageCanvas.width, this.#imageCanvas.height);
        }
     
        const allImages = [];
        const tilesToRender = [];
        for (let i = this.#imageY <= 0 ? 0 : Math.floor(this.#imageY / this.#imageTileSize); i < Math.ceil(Math.min(this.#imageY+this.#imageCanvas.height, height) / this.#imageTileSize); i++) {
            for (let j = this.#imageX <= 0 ? 0 : Math.floor(this.#imageX / this.#imageTileSize); j < Math.ceil(Math.min(this.#imageX+this.#imageCanvas.width, width) / this.#imageTileSize); j++) {
                tilesToRender.push([i, j, i * tilesInX + j]); const flatIndex = i * tilesInX + j;
            }
        }

        let tilesDrawn = 0;
        let tilesHandled = 0;
        for (let tileToRender of tilesToRender) {
            const [i, j, flatIndex] = tileToRender;            
            if (this.#imageZoomTileCache?.[this.#zoomIndex]?.[flatIndex]) {
                const img = this.#imageZoomTileCache[this.#zoomIndex][flatIndex];
                if (img.complete) {
                    this.#imageCanvas.style.filter = updateCanvasFilter;
                    ctx.drawImage(img, this.#imageX < 0 ? -this.#imageX + img.tilex : img.tilex - this.#imageX, this.#imageY < 0 ? -this.#imageY + img.tiley : img.tiley - this.#imageY);
                    tilesDrawn++;
                    if (++tilesHandled === tilesToRender.length)  {
                        // Redraw all tiles to get rid of the lines
                        /*for (let t of tilesToRender) {
                            const img = this.#imageZoomTileCache[this.#zoomIndex][t[2]];
                            ctx.drawImage(img, this.#imageX < 0 ? -this.#imageX + img.tilex : img.tilex - this.#imageX, this.#imageY < 0 ? -this.#imageY + img.tiley : img.tiley - this.#imageY);
                        } */                   
                        this.renderImageDone(tilesDrawn === tilesHandled);
                    }
                }    
                else {
                    const tilex = j*this.#imageTileSize;
                    const tiley = i*this.#imageTileSize;                    
                    ctx.clearRect(this.#imageX < 0 ? -this.#imageX + tilex : tilex - this.#imageX, this.#imageY < 0 ? -this.#imageY + tiley : tiley - this.#imageY, this.#imageTileSize, this.#imageTileSize);
                }                
            }

            else {
                const z = this.#zoomIndex;
                this.#imageZoomTileCache[z][flatIndex] = new Image(this.#imageTileSize, this.#imageTileSize);
                this.#imageZoomTileCache[z][flatIndex].addEventListener("load", (event) => {
                    const img = event.target;
                    const { s: scale,p: power, w: width, h: height } = this.#imageZoomSizes[this.#zoomIndex];
                    const ctx = this.#imageCanvas.getContext("2d");
                    ctx.setTransform(1, 0, 0, 1, 0, 0);
                    ctx.translate(this.#imageCanvas.width/2, this.#imageCanvas.height/2);
                    ctx.scale(scale, scale);        
                    ctx.translate(-this.#imageCanvas.width/2, -this.#imageCanvas.height/2);                    
                    if (img.zoomIndex === this.#zoomIndex/* && localNonce === this.renderImageNonce*/) {
                        this.#imageCanvas.style.filter = updateCanvasFilter;
                        ctx.drawImage(img, this.#imageX < 0 ? -this.#imageX + img.tilex : img.tilex - this.#imageX, this.#imageY < 0 ? -this.#imageY + img.tiley : img.tiley - this.#imageY);
                        tilesDrawn++;
                    }
                    if (++tilesHandled === tilesToRender.length) {
                        // Redraw all tiles to get rid of the lines
                        /*for (let t of tilesToRender) {
                            const img = this.#imageZoomTileCache[this.#zoomIndex][t[2]];
                            ctx.drawImage(img, this.#imageX < 0 ? -this.#imageX + img.tilex : img.tilex - this.#imageX, this.#imageY < 0 ? -this.#imageY + img.tiley : img.tiley - this.#imageY);
                        }*/                       
                        this.renderImageDone(tilesDrawn === tilesHandled);
                    }
                });
                const tilex = j*this.#imageTileSize;
                const tiley = i*this.#imageTileSize;
                this.#imageZoomTileCache[z][flatIndex].zoomIndex = z;
                this.#imageZoomTileCache[z][flatIndex].tilex = tilex;
                this.#imageZoomTileCache[z][flatIndex].tiley = tiley;
                this.#imageZoomTileCache[z][flatIndex].src = this.loadTile(this.currentSeqIndex, power, j, i, selchannel, selbinlayers, gains);
                allImages.push(this.#imageZoomTileCache[z][flatIndex]);
            }
        }
    }

    async renderImageDone(allTilesWereDrawn) {
        if (allTilesWereDrawn)
            this.checkAndAdvancePlayingLoop();
    }

    renderVolume() {
        this.#volumeViewRenderer.render(this.#volumeViewScene, this.#volumeViewCamera);
    }

    async loadImageMetadata() {
    }

    async autoLuts(seqindex) {
    }    

    async loadVolumeInfo(seqindex, reqpower) {
    }

    clearFile() {
        this.#allLoopIndexes = [];
        this.#is3d = false;
        this.#is8bitRgb = false;
        this.#imageWidth = 0;
        this.#imageHeight = 0;
        this.#channelIndex = -1;
        this.#binaryIndexes = [];
        this.#imageZoomSizes = [];
        this.#allChannelNames = [];
        this.#allChannelColors = [];
        this.#allChannelGains = [];
        this.#allBinLayerNames = [];
        this.#allLoopIndexes = [];
        this.#allLoopIndexesMax = [];
        this.#currentLoopIndexes = [];        
        this.#playingLoop = "";
        this.#imageTileSize = 256;
        this.#volumeReqPower = 9;

        this.viewingMode = ViewingMode.imageView;
        this.clearCanvas();
        this.updateNavigatorElement();
    }    

    async loadFile() {
        const meta = await this.loadImageMetadata();
        this.#channelIndex = -1;        
        this.#binaryIndexes = [];        
        this.#is3d = meta.is3d;
        this.#is8bitRgb = meta.is8bitRgb;
        this.#imageWidth = meta.width;
        this.#imageHeight = meta.height;
        this.#imageZoomSizes = [];
        this.#allChannelNames = meta.channelNames;
        this.#allChannelColors = meta.channelColors;
        this.#allChannelGains = meta.channelNames.map(() => 1.0);
        this.#allBinLayerNames = meta.binaryNames;
        this.#allLoopIndexes = [];
        this.#allLoopIndexesMax = [];
        this.#currentLoopIndexes = [];
        this.#playingLoop = "";
        this.#imageTileSize = meta?.imageTileSize ?? 256;
        this.#volumeReqPower = meta?.volumeReqPower ?? 9;
        this.#initialLoopPos = meta?.initialLoopPos ?? {};

        const blpo2 = (v) => {
            v--; v |= v >> 1; v |= v >> 2; v |= v >> 4; v |= v >> 8; v |= v >> 16; v++;
            return v;
        };        

        if (Array.isArray(meta.allLoopIndices) && 0 < meta.allLoopIndices.length) {
            const dims = Object.getOwnPropertyNames(meta.allLoopIndices[0]);
            this.#allLoopIndexesMax = Object.fromEntries(dims.map(value => [ value, 0 ]))
            for (let index of meta.allLoopIndices) {
                for (let dim of dims) {
                    const i = index[dim];
                    this.#allLoopIndexesMax[dim] = Math.max(this.#allLoopIndexesMax[dim], index[dim])
                }
                this.#allLoopIndexes.push(JSON.stringify(index));
            }
            this.#currentLoopIndexes = meta?.initialLoopPos ?? meta.allLoopIndices[0];
        }

        this.updateNavigatorElement();
    
        const imageFullPowerSize = blpo2(this.#imageHeight <= this.#imageWidth ? this.#imageWidth : this.#imageHeight);
        for (let i = 4; i <= 20; i++) {
            const k = 1 << i;
            let zoom = 100 * k / imageFullPowerSize;
            if (9 <= i || k === imageFullPowerSize) {
                const downsampledWidth = Math.floor(this.#imageWidth * k / imageFullPowerSize);
                const downsampledHeight = Math.floor(this.#imageHeight * k / imageFullPowerSize);

                const tileCache = new Array(Math.ceil(downsampledWidth / this.#imageTileSize) * Math.ceil(downsampledHeight / this.#imageTileSize))
                this.#imageZoomSizes.push({s:1.0, z: zoom.toFixed(zoom < 1 ? 2 : (zoom < 10 ? 1 : 0)), w: downsampledWidth, h: downsampledHeight, p: i});
                this.#imageZoomTileCache.push(tileCache);

                zoom *= 1.4142;
                this.#imageZoomSizes.push({s:1.4142, z: zoom.toFixed(zoom < 1 ? 2 : (zoom < 10 ? 1 : 0)), w: downsampledWidth, h: downsampledHeight, p: i});
                this.#imageZoomTileCache.push(tileCache);

                if (k === imageFullPowerSize) {
                    zoom = 200;
                    this.#imageZoomSizes.push({s:2.0, z: zoom.toFixed(zoom < 1 ? 2 : (zoom < 10 ? 1 : 0)), w: downsampledWidth, h: downsampledHeight, p: i});
                    this.#imageZoomTileCache.push(tileCache);
                    zoom *= 1.4142;
                    this.#imageZoomSizes.push({s:zoom/100.0, z: zoom.toFixed(zoom < 1 ? 2 : (zoom < 10 ? 1 : 0)), w: downsampledWidth, h: downsampledHeight, p: i});
                    this.#imageZoomTileCache.push(tileCache);
                    zoom = 400;
                    this.#imageZoomSizes.push({s:4.0, z: zoom.toFixed(zoom < 1 ? 2 : (zoom < 10 ? 1 : 0)), w: downsampledWidth, h: downsampledHeight, p: i});
                    this.#imageZoomTileCache.push(tileCache);
                    zoom *= 1.4142;
                    this.#imageZoomSizes.push({s:zoom/100.0, z: zoom.toFixed(zoom < 1 ? 2 : (zoom < 10 ? 1 : 0)), w: downsampledWidth, h: downsampledHeight, p: i});
                    this.#imageZoomTileCache.push(tileCache);                    
                    zoom = 800;
                    this.#imageZoomSizes.push({s:8.0, z: zoom.toFixed(zoom < 1 ? 2 : (zoom < 10 ? 1 : 0)), w: downsampledWidth, h: downsampledHeight, p: i});
                    this.#imageZoomTileCache.push(tileCache);                    
                    break;
                }
            }
        }
    
        this.#zoomIndex = -1; // to force render
        this.clearCache();        
        this.bestFit();
    }

    updateNavigatorElement() {
        this.#navigator.innerText = "";
        if (Array.isArray(this.#allLoopIndexes) && 0 < this.#allLoopIndexes.length) {
            const ndtitles = { "w": "Well", "m": "Point", "t": "Time", "z": "Z-slice" };
            for (let loop of ["w", "m", "t", "z"]) {
                const maxindex = this.#allLoopIndexesMax[loop];                
                const curindex = this.#currentLoopIndexes[loop];
                if (this.#allLoopIndexesMax.hasOwnProperty(loop) && 0 < maxindex) {
                    let el = null;                        
                    el = document.createElement("div");
                    el.id = `ndnav-label-${loop}`;
                    el.className = "ndnav-dim-label";                    
                    el.innerText = `${ndtitles[loop]} ${curindex+1}/${maxindex+1}`;
                    this.#navigator.appendChild(el);
                    el = document.createElement("div");
                    el.id = `ndnav-track-${loop}`;
                    el.className = "ndnav-dim-track";
                    el.loop = loop;
                    el.alltickscount = maxindex + 1;                    
                    const step = Math.floor(el.alltickscount / Math.min(60, el.alltickscount));
                    for (let i = 0; i <= maxindex; i += step) {
                        const tick = document.createElement("span");
                        tick.className = "ndnav-tick";
                        tick.loop = loop;
                        tick.index_in_loop = i;
                        tick.onclick = (e) => {
                            const that = e.target;
                            if (that.parentElement && !that.parentElement.classList.contains('lim-disabled')) {
                                const loopIndexes = this.currentLoopIndexes;
                                loopIndexes[that.loop] = that.index_in_loop;
                                this.currentLoopIndexes = loopIndexes;
                            }
                        }
                        if (Math.floor(i/step) == Math.floor(curindex/step))
                            tick.classList.add("selected");
                        el.appendChild(tick);
                    }
                    this.#navigator.appendChild(el);
                    el = document.createElement("div");
                    el.className = "ndnav-dim-ctrl";
                    el.id = `ndnav-ctrl-${loop}`

                    let btn = document.createElement("img");
                    btn.src = `${this.resoucePrefix}playbar_step_back.svg`
                    btn.loop = loop;
                    btn.onclick = (e) => {
                        const that = e.target;
                        if (that.parentElement && !that.parentElement.classList.contains('lim-disabled')) {
                            const loopIndexes = this.currentLoopIndexes;
                            loopIndexes[that.loop] = 0;
                            this.currentLoopIndexes = loopIndexes;
                        }
                    };                    
                    el.appendChild(btn);                    

                    btn = document.createElement("img");
                    btn.src = `${this.resoucePrefix}playbar_fast_back.svg`
                    btn.loop = loop;
                    btn.onclick = (e) => {
                        const that = e.target;
                        if (that.parentElement && !that.parentElement.classList.contains('lim-disabled')) {
                            const loopIndexes = this.currentLoopIndexes;
                            loopIndexes[that.loop] = Math.max(0, loopIndexes[that.loop] - 1);
                            this.currentLoopIndexes = loopIndexes;
                        }
                    };
                    el.appendChild(btn);

                    const play_btn = document.createElement("img");
                    play_btn.id = `ndnav-play-${loop}`;                    
                    play_btn.style.marginLeft = "4px";
                    play_btn.style.marginRight = "4px";
                    play_btn.src = `${this.resoucePrefix}playbar_play.svg`
                    play_btn.loop = loop;
                    play_btn.onclick = (e) => {
                        const that = e.target;
                        if (this.playingLoop === that.loop) {
                            this.playingLoop = "";
                        }
                        else if (that.parentElement && !that.parentElement.classList.contains('lim-disabled')) {
                            this.playingLoop = that.loop;
                        }
                    }
                    play_btn.setPlayIcon = () => {                        
                        play_btn.src = `${this.resoucePrefix}playbar_play.svg`
                    };
                    play_btn.setPauseIcon = () => {                        
                        play_btn.src = `${this.resoucePrefix}playbar_pause.svg`
                    };                                        
                    el.appendChild(play_btn);                    

                    btn = document.createElement("img");
                    btn.src = `${this.resoucePrefix}playbar_fast_forw.svg`
                    btn.loop = loop;
                    btn.onclick = (e) => {
                        const that = e.target;
                        if (that.parentElement && !that.parentElement.classList.contains('lim-disabled')) {
                            const loopIndexes = this.currentLoopIndexes;
                            loopIndexes[that.loop] = Math.min(loopIndexes[that.loop] + 1, maxindex);
                            this.currentLoopIndexes = loopIndexes;
                        }
                    };
                    el.appendChild(btn);

                    btn = document.createElement("img");
                    btn.src = `${this.resoucePrefix}playbar_step_forw.svg`
                    btn.loop = loop;
                    btn.onclick = (e) => {
                        const that = e.target;
                        if (that.parentElement && !that.parentElement.classList.contains('lim-disabled')) {
                            const loopIndexes = this.currentLoopIndexes;
                            loopIndexes[that.loop] = maxindex;
                            this.currentLoopIndexes = loopIndexes;
                        }
                    };
                    el.appendChild(btn);                    

                    this.#navigator.appendChild(el);
                }
            }
        }            
    
        this.#navigator.style.display = 0 == this.#navigator.childElementCount ? "none" : "grid";
    }

    get valid() {
        return (0 < this.#imageWidth * this.#imageHeight) && 0 < this.#allLoopIndexes.length;
    }    

    get is3d() {
        return this.#is3d;
    }

    get is8bitRgb() {
        return this.#is8bitRgb;
    }

    get channelIndex() {
        return this.#channelIndex;
    }

    set channelIndex(value) {
        if (this.#channelIndex === value)
            return;

        this.#channelIndex = value;
        this.clearCache();
        this.update();
    }    

    get binaryIndexes() {
        return this.#binaryIndexes;
    }

    set binaryIndexes(value) {
        if (!Array.isArray(value) || JSON.stringify(this.#binaryIndexes) === JSON.stringify(value?.sort?.()))
            return;

        this.#binaryIndexes = [...value.sort()];
        this.clearCache();
        this.update();        
    }

    get zoomIndex() {
        return this.#zoomIndex;
    }

    set zoomIndex(value) {
        this.#setZoomIndexLow(value);
    }

    get channelNames() {
        return this.#allChannelNames;
    }

    get channelColors() {
        return this.#allChannelColors;
    }

    get lutsEnabled() {
        return this.#lutsEnabled;
    }

    set lutsEnabled(val) {
        if (this.#lutsEnabled !== val) {
            this.#lutsEnabled = val;
            this.clearCache();
            this.update();        
        }
    }

    get channelGains() {
        return this.#allChannelGains;
    }

    set channelGains(val) {
        this.#allChannelGains = val;
        if (this.#lutsEnabled) {
            this.clearCache();
            this.update();
        }
    }    

    setChannelGain(index, value) {
        this.#allChannelGains[index] = Math.max(1.0, value);
        //const meanGain = this.#allChannelGains.reduce((a, b) => a + b) / this.#allChannelGains.length;
        //this.#imageCanvas.style.filter = `brightness(${meanGain})`;
        if (this.#lutsEnabled) {
            this.clearCache();
            this.update();
        }
    }

    get showSingleChannelInMono() {
        return this.#showSingleChannelInMono;
    }

    set showSingleChannelInMono(val) {
        if (this.#showSingleChannelInMono === val)
            return;
        this.#showSingleChannelInMono = val;
        if (this.#channelIndex !== -1 || this.#allChannelNames.length === 1) {
            this.update();            
        }
    }

    get playingLoop() {
        return this.#playingLoop;
    }

    set playingLoop(val) {
        if (this.#playingLoop === val)
            return;

        if (this.#playingLoop)
            document.getElementById(`ndnav-play-${this.#playingLoop}`).setPlayIcon();
        this.#playingLoop = val;
        if (this.#playingLoop)
            document.getElementById(`ndnav-play-${this.#playingLoop}`).setPauseIcon();

        this.update();
    }    

    get binaryNames() {
        return this.#allBinLayerNames;
    }

    get imageZoomSizes() {
        return this.#imageZoomSizes;
    }

    get imageCanvasDomElement() {
        return this.#imageCanvas;
    }

    get navigatorDomElement() {
        return this.#navigator;
    }    

    get viewingMode() {
        return this.#viewingMode;
    }

    set viewingMode(value) {
        if (this.#viewingMode === value)
            return;
        this.playingLoop = "";
        this.#viewingMode = value;
        switch (this.#viewingMode) {
            case ViewingMode.imageView:
                this.#setImageModeLow();
                break;
            case ViewingMode.volumeView:
                this.#setVolumeModeLow();
                break;                
        }
    }
}

const createLimNavigator = () => {
    const nav = document.createElement("div");
    nav.class = "lim-fill-width"
    nav.style.padding = "3px";
    nav.style.display = "none";
    nav.style.rowGap = "1px";
    nav.style.gridTemplateColumns = "10em auto max-content";
    nav.style.backgroundColor = "var(--color-window)";
    return nav;
};

const vertexShader = /* glsl */`
in vec3 position;    

uniform mat4 viewMatrix;        
uniform mat4 modelMatrix;
uniform mat4 modelViewMatrix;
uniform mat4 projectionMatrix;

out vec4 v_nearpos;
out vec4 v_farpos;
out vec3 v_position;

void main() {
    // Prepare transforms to map to "camera view". See also:
    // https://threejs.org/docs/#api/renderers/webgl/WebGLProgram
    mat4 viewtransformf = modelViewMatrix;
    mat4 viewtransformi = inverse(modelViewMatrix);

    // Project local vertex coordinate to camera position. Then do a step
    // backward (in cam coords) to the near clipping plane, and project back. Do
    // the same for the far clipping plane. This gives us all the information we
    // need to calculate the ray and truncate it to the viewing cone.
    vec4 position4 = vec4(position, 1.0);
    vec4 pos_in_cam = viewtransformf * position4;

    // Intersection of ray and near clipping plane (z = -1 in clip coords)
    pos_in_cam.z = -pos_in_cam.w;
    v_nearpos = viewtransformi * pos_in_cam;

    // Intersection of ray and far clipping plane (z = +1 in clip coords)
    pos_in_cam.z = pos_in_cam.w;
    v_farpos = viewtransformi * pos_in_cam;

    // Set varyings and output pos
    v_position = position;
    gl_Position = projectionMatrix * viewMatrix * modelMatrix * position4;
}
`;

const fragmentShader = /* glsl */`
precision highp float;
precision mediump sampler3D;

uniform int u_fmt;
uniform int u_gray;
uniform vec3 u_size;
uniform vec3 u_count;
uniform sampler3D u_data;

in vec3 v_position;
in vec4 v_nearpos;
in vec4 v_farpos;

out vec4 color;

// The maximum distance through our rendering volume is sqrt(3).
const int MAX_STEPS = 887;	// 887 for 512^3, 1774 for 1024^3
const int REFINEMENT_STEPS = 4;
const float relative_step_size = 1.0;

void cast_mip1(vec3 start_loc, vec3 step, int nsteps, vec3 view_ray);
void cast_mip4(vec3 start_loc, vec3 step, int nsteps, vec3 view_ray);

void main() {
    // Normalize clipping plane info
    vec3 farpos = v_farpos.xyz / v_farpos.w;
    vec3 nearpos = v_nearpos.xyz / v_nearpos.w;

    // Calculate unit vector pointing in the view direction through this fragment.
    vec3 view_ray = normalize(nearpos.xyz - farpos.xyz);

    // Compute the (negative) distance to the front surface or near clipping plane.
    // v_position is the back face of the cuboid, so the initial distance calculated in the dot
    // product below is the distance from near clip plane to the back of the cuboid
    float distance = dot(nearpos - v_position, view_ray);
    distance = max(distance, min((-0.5 - v_position.x) / view_ray.x, (u_size.x - 0.5 - v_position.x) / view_ray.x));
    distance = max(distance, min((-0.5 - v_position.y) / view_ray.y, (u_size.y - 0.5 - v_position.y) / view_ray.y));
    distance = max(distance, min((-0.5 - v_position.z) / view_ray.z, (u_size.z - 0.5 - v_position.z) / view_ray.z));

    // Now we have the starting position on the front surface
    vec3 front = v_position + view_ray * distance;

    // Decide how many steps to take
    int nsteps = int(-distance / relative_step_size + 0.5);
    if (nsteps < 1)
        discard;

    // Get starting location and step vector in texture coordinates
    vec3 step = ((v_position - front) / u_size) / float(nsteps);
    vec3 start_loc = front / u_size;

    // For testing: show the number of steps. This helps to establish
    // whether the rays are correctly oriented
    // color = vec4(0.0, float(nsteps) / 1.0 / u_size.x, 1.0, 1.0);
    // return;

    if (1 == u_fmt)
        cast_mip1(start_loc, step, nsteps, view_ray);
    else if (4 == u_fmt)
        cast_mip4(start_loc, step, nsteps, view_ray);
    else
        discard;

    if (color.a < 0.05)
            discard;
}

void cast_mip4(vec3 start_loc, vec3 step, int nsteps, vec3 view_ray) {
    vec4 max_col = vec4(0, 0, 0, 255);
    vec3 loc = start_loc;
    for (int iter=0; iter<nsteps; iter++) {
        vec4 col = texture(u_data, loc);
        max_col.r = max(max_col.r, col.r);
        max_col.g = max(max_col.g, col.g);  
        max_col.b = max(max_col.b, col.b);
        loc += step;
    }
    if (0 != u_gray) {
        color.r = color.g = color.b = max(max_col.r, max(max_col.g, max_col.b));    
        color.a = 255.0f;
    }
    else
        color = max_col;
}

void cast_mip1(vec3 start_loc, vec3 step, int nsteps, vec3 view_ray) {
    float max_val = -1e6;
    int max_i = 100;
    vec3 loc = start_loc;
    for (int iter=0; iter<nsteps; iter++) {
        float val = texture(u_data, loc).r;
        if (val > max_val) {
            max_val = val;
            max_i = iter;
        }
        loc += step;
    }

    // Refine location, gives crispier images
    vec3 iloc = start_loc + step * (float(max_i) - 0.5);
    vec3 istep = step / float(REFINEMENT_STEPS);
    for (int i=0; i<REFINEMENT_STEPS; i++) {
        max_val = max(max_val, texture(u_data, iloc).r);
        iloc += istep;
    }

    // Resolve final color
    color.r = max_val;
    color.g = max_val;
    color.b = max_val;
    color.a = 255.0f;
}
`;
