const itemHeight = 20;
const extraItemCount = 2;
const rootGroupId = "4813494d137e1631bba301d5acab6e7bb7aa74ce1185d456565ef51d737677b2";
const tailColId = "0c62f876ef1dea830de9f32c2f4b46dd6d74d50d15896e09ef5a2fcd4ac7e1d7";

class LimTreeViewBase extends HTMLElement {
    #headerContainer
    #treeContainer
    #sizeObserver

    #coldefs
    #colsizes
    #contentWidth
    #stickyColumnIndex

    #items
    #itemCount
    #itemGroupDepth
    #maxItemGroupDepth

    #groups
    #openGroups

    #selectedItemId

    static observedAttributes = ["header", "nesting", "selection", "src", "stickyCols", "tailCol", "theme" ];

    constructor() {
        super();
    }

    get header() {
        return this.getAttribute("header");
    }

    set header(val) {
        this.setAttribute("header", val);
    }

    get nesting() {
        return this.getAttribute("nesting");
    }

    set nesting(val) {
        this.setAttribute("nesting", val);
    }

    get nestingWidth() {
        return parseInt(this.nesting ?? "0");
    }    

    get isHeaderVisible() {
        return (this.header ?? "normal").toLowerCase() !== "none";
    }

    get selection() {
        return this.getAttribute("selection");
    }

    set selection(val) {
        this.setAttribute("selection", val);
    }

    get isSelectionEnabled() {
        return (this.selection ?? "none").toLocaleLowerCase() !== "none";
    }    

    get src() {
        return this.getAttribute("src");
    }

    set src(val) {
        this.setAttribute("src", val);
    }

    get stickyCols() {
        return this.getAttribute("stickyCols");
    }

    set stickyCols(val) {
        this.setAttribute("stickyCols", val);
    }

    get numberOfStickyCols() {
        return parseInt(this.stickyCols ?? "0") ? 1 : 0;
    }

    get tailCol() {
        return this.getAttribute("tailCol");
    }

    set tailCol(val) {
        this.setAttribute("tailCol", val);
    }

    get isTailColVisible() {
        return (this.tailCol ?? "show").toLowerCase() === "show";
    }

    get theme() {
        return this.getAttribute("theme");
    }

    set theme(val) {
        this.setAttribute("theme", val);
    }

    get themeName() {
        return (this.theme ?? "default").toLowerCase();
    }

    get headerContainer() {
        return this.#headerContainer;
    }

    get treeContainer() {
        return this.#treeContainer;
    }

    get itemCount() {
        return this.#itemCount;
    }

    get items() {
        return this.#items;
    }

    get coldefs() {
        return this.#coldefs;
    }

    get colsizes() {
        return this.#colsizes;
    }

    get selectedItem() {
        return this.#items.find(item => item.id === this.selectedItemId);
    }    

    get selectedItemId() {
        return this.#selectedItemId;
    }

    set selectedItemId(val) {
        if (JSON.stringify(this.#selectedItemId) === JSON.stringify(val))
            return;

        this._remElementClassSelected(this.#selectedItemId);

        this.#selectedItemId = val;
        this._addElementClassSelected(this.#selectedItemId);

        this?.selectedItemChanged?.();
    }

    get colBorder() {
        return 1;
    }

    get colPadding() {
        return 4;
    }

    get headerHeight() {
        return itemHeight + 2;
    }

    get calculatedWidth() {
        const style = window.getComputedStyle(this);
        return style.width.match(/\d+px/) ? parseInt(style.width) : -1;
    }

    get calculatedHeight() {
        const style = window.getComputedStyle(this);
        return style.height.match(/\d+px/) ? parseInt(style.height) : -1;
    }

    get contentWidth() {
        const scrollbar = this.calculatedHeight < this.contentHeight ? 16 : 0;
        return this.#colsizes === null ? this.calculatedWidth - scrollbar : this.#contentWidth;
    }

    get contentHeight() {
        return (this._countItemsInOpenGroups() + this._countVisibleGroups()) * itemHeight;
    }

    get visibleColRange() {
        let x = 0;
        let start = this.#colsizes.length;
        let end = 0;
        let count = 0;
        const left = Math.floor(this.scrollLeft);
        const right = Math.ceil(this.scrollLeft + this.clientWidth);
        for (let i = 0; i < this.#colsizes.length; i++) {
            if (this.#coldefs[i].visible) {
                const w = this.#colsizes[i].width;
                if (left < x + w && i < start) {
                    start = i;
                }
                if (x < right && end < i) {
                    end = i;
                }
                x += w;
                count++;
            }
        }
        return [ Math.max(0, start - extraItemCount), Math.min(end + extraItemCount, this.#colsizes.length) ];
    }

    get visibleColCount() {
        return this.#coldefs.filter(item => item.visible).length;
    }

    connectedCallback() {
        this.#coldefs = [];
        this.#items = [];
        this.#itemCount = 0;        
        this.#itemGroupDepth = [];
        this.#maxItemGroupDepth = 0;
        this.#groups = [];
        this.#selectedItemId = null;
        this._resetColSizes();
        this._resetOpenedGroups();

        if (!this.#treeContainer) {
            const shadow = this.attachShadow({ mode: "open" });

            const sheet = new CSSStyleSheet();
            const color_mid = "var(--color-mid)";
            const color_window = "var(--color-window)";
            const color_base = "var(--color-base)";
            const color_altbase = "var(--color-altbase)";
            const color_highlight = "var(--color-highlight)";

            const border = `${this.colBorder}px solid ${color_mid}`;            
            sheet.insertRule(`*, *::before, *::after { box-sizing: border-box; }`, sheet.cssRules.length);
            sheet.insertRule(`.header-container { position: sticky; top: 0; width: 100%; height: ${this.headerHeight}px; z-index: 2; }`, sheet.cssRules.length);
            sheet.insertRule(`.tree-container { position: relative; width: 100%; }`, sheet.cssRules.length);
            sheet.insertRule(`.row { position: absolute; background-color: ${color_base}; }`, sheet.cssRules.length);
            sheet.insertRule(`.cell { padding: ${this.colPadding}px; user-select: none; position: absolute; }`, sheet.cssRules.length);
            if (this.themeName === "simple") {
                sheet.insertRule(`.selected { background-color: ${color_highlight} !important; }`, sheet.cssRules.length);
            }
            else {
                sheet.insertRule(`.selected { background-color: ${color_highlight} !important; }`, sheet.cssRules.length);
                sheet.insertRule(`.header { border-top: ${border}; border-bottom: ${border}; background-color: ${color_window}; }`, sheet.cssRules.length);
                sheet.insertRule(`.group { border-bottom: ${border}; background-color: ${color_window}; }`, sheet.cssRules.length);               
                sheet.insertRule(`.data { background-color: ${color_base}; }`, sheet.cssRules.length);
                sheet.insertRule(`.odd { background-color: ${color_altbase}; }`, sheet.cssRules.length);
                sheet.insertRule(`.lborder { border-left: ${border}; }`, sheet.cssRules.length);
                sheet.insertRule(`.rborder { border-right: ${border}; }`, sheet.cssRules.length);
            }
            shadow.adoptedStyleSheets = [sheet];


            this.#headerContainer = createHeaderContainer();
            shadow.appendChild(this.#headerContainer);

            this.#treeContainer = createTreeContainer();
            shadow.appendChild(this.#treeContainer);
        }    

        if (!this.#sizeObserver) {
            this.#sizeObserver = new ResizeObserver((entries) => {
                this._resetColSizes();
                this.render();
            });            
            this.#sizeObserver.observe(this);            
        }

        this.update();
    }
    
    disconnectedCallback() {
        if (this.#sizeObserver) {
            this.#sizeObserver.disconnect()
            this.#sizeObserver = null;
        }

        if (this.#treeContainer) {
            this.removeChild(this.#treeContainer);
            this.#treeContainer = null;
        }
    }
    
    adoptedCallback() {
    }
    
    attributeChangedCallback(name, oldValue, newValue) {
        if (name === "header"){
            this.render();
        }
        if (name === "nesting"){
            this._resetColSizes();
            this.render();
        }        
        else if (name === "selection") {
            this.render();
        }        
        else if (name === "src") {
            this.update();
        }
        else if (name === "stickyCols") {
            this._resetColSizes();
            this.render();
        }
        else if (name === "tailCol") {
            if (0 < this.#coldefs.length && this.#coldefs[this.#coldefs.length-1].id === tailColId) {
                this._resetColSizes();
                this.#coldefs[this.#coldefs.length-1].visible = this.isTailColVisible;
                this.render();
            }
        }
    }

    async update() {
        if (!document.body.contains(this))
            return;

        await this.fetchData();
        if (this.selectedItemId && !this.#items.find(item => item.id === this.selectedItemId))
            this.selectedItemId = null;
        this.render();      
    }

    async fetchData() {
        if (this.src === null)
            return;
        
        const data_prefix = "data:application/json;base64,";
        if (this.src.startsWith(data_prefix)) {
            const data = JSON.parse(atob(this.src.substring(data_prefix.length)));
            return new Promise((resolve, reject) => {
                setTimeout(() => { 
                    this._setData(data);
                    resolve();
                })
            })
        }
        else {
            const response = await fetch(this.src);
            const data = await response.json();
            this._setData(data);
        }
    }    

    render() {
    }

    _addElementClassSelected(id) {
        if (id) {
            const selitem = this.shadowRoot.getElementById(id);
            selitem?.classList?.add?.("selected");
        }
    }
    
    _remElementClassSelected(id) {
        if (id) {
            const selitem = this.shadowRoot.getElementById(id);
            selitem?.classList?.remove?.("selected");
        }
    }

    _resetColSizes() {
        this.#colsizes = null;
        this.#contentWidth = 0;    
        this.#stickyColumnIndex = -1;
    }

    _resetOpenedGroups() {
        this.#openGroups = null;
    }

    _setData(data) {
        this.#coldefs = data.coldefs;
        for (let i = 0; i < this.#coldefs.length; i++) {
            const coldef = this.#coldefs[i];
            coldef.visible = !(coldef?.hidden ?? false);
            if (coldef?.fmtfncode) {
                eval(coldef.fmtfncode)(coldef);
            }
            if (coldef?.stylefncode) {
                eval(coldef.stylefncode)(coldef);
            }
        }

        if (0 < this.#coldefs.length && this.#coldefs[this.#coldefs.length-1].id !== tailColId) {
            this.#coldefs.push({ id: tailColId, width:'1fr', style: { padding: "0" }, visible: this.isTailColVisible });
        }

        this.#items = data.rowdata;
        this.#itemCount = this.#items.length;
        this.#groups = data?.groups ?? [ { id: rootGroupId, depth: 0, groupcount: 0, rowcount: this.#itemCount, rows: [ 0, this.#itemCount ] } ];
        this.#groups.forEach(item => item.visible = item.id !== rootGroupId);
        this.#itemGroupDepth = this.#groups.map(group => (0 < group.rowcount ? Array(group.rowcount).fill(group.depth) : [])).reduce((p, c) => p.concat(c));
        this.#maxItemGroupDepth = this.#groups.map(group => (0 < group.rowcount ? group.depth : 0)).reduce((p, c) => Math.max(p, c))
        if (this.#itemGroupDepth.length !== this.#itemCount) {
            throw new Error("Sum group rowcounts is not equal to itemCout!");
        }

        if (this.#openGroups instanceof Set) {
            this.#groups.forEach(item => item.open = this.#openGroups.has(item.id));
        }
        else {
            this.#groups.forEach(item => item.open = true);
            this.#openGroups = new Set(this.#groups.map(item => item.id));            
        }

        const groupByIds = new Set(this.#groups.map(group => group?.colid).filter(item => !!item));
        this.#coldefs.forEach(item => item.visible = item.visible && !groupByIds.has(item.id));

        this._resetColSizes();  
    }

    _countVisibleGroups() {
        let gcount = 0;
        let skipDeeper = Number.MAX_VALUE;
        for (let group of this.#groups) {
            if (!group.visible || skipDeeper < group.depth)
                continue;
            skipDeeper = group.open ? Number.MAX_VALUE : group.depth;
            gcount++;
        }
        return gcount;
    }    

    _countItemsInOpenGroups() {
        let rcount = 0;
        let skipDeeper = Number.MAX_VALUE;
        for (let group of this.#groups) {
            if (skipDeeper < group.depth)
                continue;
            if (group.open) {
                rcount += group.rowcount;
                skipDeeper = Number.MAX_VALUE;
            }
            else {
                skipDeeper = group.depth;
            }
        }
        return rcount;
    }

    _updateColSizes() {
        if (!this.#coldefs?.length || !this.#itemCount)
            return;

        let total_width = this.contentWidth;
        if (total_width < 0)
            return false;

        if (this.#colsizes === null) {
            this.#colsizes = [];
            let viscount = 0;
            for (let j = 0; j < this.#coldefs.length; j++) {
                const colsize = {};                
                const coldef = this.#coldefs[j];
                const min_width = parseInt(coldef?.minwidth ?? "0");
                const width_def = coldef?.width ?? "auto";
                const nesting_width = coldef.visible && 0 === viscount ? this.nestingWidth * this.#maxItemGroupDepth : 0;
                if (width_def.match(/\d+px/)) {
                    colsize.type = "px";
                    colsize.width = nesting_width + parseInt(width_def);
                }
                else if (width_def.match(/\d+%/)) {
                    colsize.type = "percent";
                    colsize.percent = parseInt(width_def);
                    colsize.width = Math.max(nesting_width + min_width, Math.floor(colsize.percent * total_width / 100));
                }                
                else if (width_def.match(/\d+fr/)) {
                    colsize.type = "fr";
                    colsize.num = parseInt(width_def);
                }
                else {
                    colsize.type = "auto";
                    colsize.header_width = LimGetTextSize(coldef.title, "11px Tahoma").width;
                    colsize.items_max_width = 0;
                    for (let k = 0; k < this.#items.length; k++) {
                        const data = this.#items?.[k]?.[coldef.id];
                        if (typeof data !== "undefined") {
                            const itemText = coldef?.fmtfn?.(data) ?? data;
                            const w = LimGetTextSize(itemText).width;
                            if (colsize.items_max_width < w)
                                colsize.items_max_width = w;
                        }
                    }                    
                    colsize.items_max_width = nesting_width + colsize.items_max_width;
                    colsize.width = Math.max(min_width, Math.ceil(Math.max(colsize.header_width, colsize.items_max_width))) + 2*this.colBorder + 2*this.colPadding;
                }
                if (coldef.visible) {
                    viscount++;
                }
                this.#colsizes.push(colsize);
            }
        }

        let fr_denom = 0;
        let fr_width = total_width; 
        for (let j = 0; j < this.#coldefs.length; j++) {
            const coldef = this.#coldefs[j];
            const colsize = this.#colsizes[j];
            if (coldef.visible) { 
                if (colsize.type === "fr") {
                    fr_denom += colsize?.num ?? 0;
                }
                else {
                    fr_width -= colsize?.width ?? 0;
                }
            }
        }

        this.#contentWidth = 0;
        this.#stickyColumnIndex = -1;
        for (let i = 0; i < this.#coldefs.length; i++) {
            const coldef = this.#coldefs[i];
            const colsize = this.#colsizes[i];
            if (colsize.type === "fr") {
                const min_width = parseInt(coldef?.minwidth ?? "0");
                colsize.width = Math.max(min_width, Math.floor(fr_width * colsize.num / fr_denom));
            }
            if (coldef.visible) {
                this.#contentWidth += colsize.width;
                if (0 < this.numberOfStickyCols && this.#stickyColumnIndex < 0) {
                    this.#stickyColumnIndex = i;
                }
            }
        }

        return true;
    }

    _createHeaderRowItem(text, style, width, height) {
        const el =  createTreeRowItem(width, height);
        el.textContent = text;
        for (let s of Object.getOwnPropertyNames(style))
            el.style[s] = style[s];        
        return el;
    }

    _createHeaderRow(start, end) {
        const el =  document.createElement("div");
        el.classList.add("header");
        el.style.flex = "initial";
        el.style.position = "absolute";
        el.style.height = `${this.headerHeight}px`;
        el.style.top = 0;

        let viscount = 0;
        let totalWidth = 0;
        for (let i = 0; i < this.#coldefs.length; i++) {
            const coldef = this.#coldefs[i];
            const itemWidth = this.#colsizes[i].width;        
            if (coldef.visible && 0 < itemWidth) {
                if (start <= i && i < end && this.#stickyColumnIndex !== i) {
                    const itemStyle = coldef?.headerStyle ?? {};
                    const elItem = this._createHeaderRowItem(coldef?.title ?? "", itemStyle, itemWidth, itemHeight);
                    if (this.#stickyColumnIndex + 1 < i)
                        elItem.classList.add("lborder");
                    elItem.style.left = `${totalWidth}px`;
                    elItem.style.top = 0;
                    el.appendChild(elItem);
                }
                totalWidth += itemWidth;
                viscount++;                
            }
        }
        if (0 <= this.#stickyColumnIndex) {
            const coldef = this.#coldefs[this.#stickyColumnIndex];
            const itemWidth = this.#colsizes[this.#stickyColumnIndex].width;        
            const itemStyle = coldef?.headerStyle ?? {};
            const elItem = this._createHeaderRowItem(coldef?.title ?? "", itemStyle, itemWidth, itemHeight);
            if (1 < this.visibleColCount)
                elItem.classList.add("rborder");
            elItem.style.background = "inherit";
            elItem.style.left = `${this.scrollLeft}px`;
            elItem.style.top = 0;
            el.appendChild(elItem);
        }

        el.style.width = `${this.contentWidth}px`;
        return el;
    }

    _createDataRowItem(text, style, width, height) {
        const el =  createTreeRowItem(width, height);
        el.textContent = text;
        for (let s of Object.getOwnPropertyNames(style))
            el.style[s] = style[s];
        return el;
    }

    _createDataRow(y, itemIndex, start, end) {
        const item = this.#items[itemIndex];
        const elRow = createTreeRow(this.contentWidth, itemHeight);
        elRow.classList.add("data");
        elRow.classList.add(itemIndex % 2 === 0 ? "even" : "odd")
        if (typeof item?.id !== "undefined")
            elRow.id = `${item.id}`;
        elRow.style.left = 0;
        elRow.style.top = `${y}px`;

        if (this.isSelectionEnabled) {
            elRow.onclick = () => { 
                this.selectedItemId = item.id;
            };
            if (item.id === this.selectedItemId) {
                elRow.classList.add("selected");  
            }      
        }

        let viscount = 0;
        let totalWidth = 0;
        for (let i = 0; i < this.#coldefs.length; i++) {
            const coldef = this.#coldefs[i];
            const itemWidth = this.#colsizes[i].width; 
            if (coldef.visible && 0 < itemWidth) {
                if (start <= i && i < end && this.#stickyColumnIndex !== i) {
                    const data = item?.[coldef.id];
                    const itemText = typeof data === "undefined" ? "" : (coldef?.fmtfn?.(data) ?? data);
                    const itemStyle = { ...(coldef?.style ?? {}) };
                    const itemStyle2 = typeof data === "undefined" ? {} : (coldef?.stylefn?.(data) ?? {});
                    for (let s of Object.getOwnPropertyNames(itemStyle2))
                        itemStyle[s] = itemStyle2[s];
                    const elItem = this._createDataRowItem(itemText, itemStyle, itemWidth, itemHeight);
                    if (this.#stickyColumnIndex + 1 < i)
                        elItem.classList.add("lborder");
                    if (0 === viscount && this.nestingWidth)
                        elItem.style.paddingLeft = `${this.nestingWidth * this.#itemGroupDepth[itemIndex] + this.colPadding}px`;
                    elItem.style.left = `${totalWidth}px`;
                    elItem.style.top = 0;                
                    elRow.appendChild(elItem);
                }
                totalWidth += itemWidth;
                viscount++;
            }
        }
        if (0 <= this.#stickyColumnIndex) {
            const coldef = this.#coldefs[this.#stickyColumnIndex];
            const itemWidth = this.#colsizes[this.#stickyColumnIndex].width;            
            const data = item?.[coldef.id];
            const itemText = typeof data === "undefined" ? "" : (coldef?.fmtfn?.(data) ?? data);
            const itemStyle = { ...(coldef?.style ?? {}) };
            const itemStyle2 = typeof data === "undefined" ? {} : (coldef?.stylefn?.(data) ?? {});
            for (let s of Object.getOwnPropertyNames(itemStyle2))
                itemStyle[s] = itemStyle2[s];
            const elItem = this._createDataRowItem(itemText, itemStyle, itemWidth, itemHeight);
            if (1 < this.visibleColCount)
                elItem.classList.add("rborder");
            if (this.nestingWidth)
                elItem.style.paddingLeft = `${this.nestingWidth * this.#itemGroupDepth[itemIndex] + this.colPadding}px`;
            elItem.style.background = "inherit";            
            elItem.style.left = `${this.scrollLeft}px`;
            elItem.style.top = 0;                
            elRow.appendChild(elItem);            
        }

        return elRow;
    }

    _createGroupRow(y, groupIndex) {
        const elRow = createTreeRow(this.contentWidth, itemHeight);
        const group = this.#groups[groupIndex];
        elRow.classList.add("group");
        if (typeof group?.id !== "undefined") {
            elRow.id = `${group.id}`;
            elRow.onclick = () => {
                group.open = !group.open;
                if (group.open) {
                    this.#openGroups.add(group.id);
                }
                else {
                    this.#openGroups.delete(group.id);
                }
                this.render();
            };            
        }
        elRow.style.left = 0;
        elRow.style.top = `${y}px`;
                

        const title = `${group.open ? "▼" : "►"} ${group?.title ?? ""}`
        const elItem = this._createDataRowItem(title, {}, this.clientWidth, itemHeight);
        elItem.style.paddingLeft = `${this.nestingWidth * (group.depth - 1) + this.colPadding}px`;
        elItem.style.left = `${this.scrollLeft}px`;
        elItem.style.top = 0;                
        elRow.appendChild(elItem);        
        return elRow;
    }

    _render_rows(colStart, colEnd) {
        let pxcount = 0;
        let skipDeeper = Number.MAX_VALUE;
        const view_top = Math.floor(this.scrollTop - extraItemCount * itemHeight);
        const view_bottom = Math.ceil(view_top + this.clientHeight + 2 * extraItemCount * itemHeight);
        for (let i = 0; i < this.#groups.length; i++) {
            const group = this.#groups[i];
            if (skipDeeper < group.depth)
                continue;
            skipDeeper = group.open ? Number.MAX_VALUE : group.depth;
            if (group.visible) {
                if (view_top <= pxcount + itemHeight) {
                    const row = this._createGroupRow(pxcount, i);
                    this.treeContainer.appendChild(row);
                }
                pxcount += itemHeight;
                if (view_bottom <= pxcount)
                    return;
            }
            if (0 == group.groupcount && group.depth < skipDeeper) {
                if (view_top <= pxcount + group.rowcount * itemHeight &&  pxcount < view_bottom) {
                    for (let j = 0; j < group.rowcount; j++) {
                        if (view_top <= pxcount + itemHeight) {
                            const row = this._createDataRow(pxcount, group.rows[0] + j, colStart, colEnd);
                            this.treeContainer.appendChild(row);                        
                        }
                        pxcount += itemHeight;
                        if (view_bottom <= pxcount)
                            return;                        
                    }
                }
                else {
                    pxcount += group.rowcount * itemHeight; 
                }
            }
        }
    }    
}

export class LimVirtualTreeView extends LimTreeViewBase {
    #onscroll

    constructor() {
        super();
    }

    connectedCallback() {
        super.connectedCallback();

        if (!this.#onscroll) {
            this.#onscroll = () => this.render();
            this.addEventListener('scroll', this.#onscroll);            
        }
    }

    disconnectedCallback() {
        super.disconnectedCallback();

        this.removeEventListener('scroll', this.#onscroll);
        this.#onscroll = null;
    }    

    render() {       
        if (!this._updateColSizes())
            return;

        const [ colStart, colEnd ] = this.visibleColRange;

        this.treeContainer.innerHTML = "";
        this.treeContainer.style.width = `${this.contentWidth}px`;
        this.treeContainer.style.height = `${this.contentHeight}px`;
        this._render_rows(colStart, colEnd);

        this.headerContainer.innerHTML = "";
        if (this.isHeaderVisible) {        
            this.headerContainer.style.display = "block";
            this.headerContainer.style.width = `${this.contentWidth}px`;            
            this.headerContainer.appendChild(this._createHeaderRow(colStart, colEnd));
        }
        else {
            this.headerContainer.style.display = "none";
        }        
    } 
}

const createHeaderContainer = () => {
    const el = document.createElement("div");
    el.classList.add("header-container");
    return el;
};

const createTreeContainer = () => {
    const el = document.createElement("div");
    el.classList.add("tree-container")
    return el;
};

const createTreeRow = (w, h) => {
    const el = document.createElement("div");
    el.classList.add("row");
    el.style.width = `${w}px`;    
    el.style.height = `${h}px`;
    return el;
};

const createTreeRowItem = (w, h) => {
    const el = document.createElement("span");
    el.classList.add("cell");
    el.style.width = `${w}px`;    
    el.style.height = `${h}px`;
    return el;
};

customElements.define('lim-virtual-treeview', LimVirtualTreeView);