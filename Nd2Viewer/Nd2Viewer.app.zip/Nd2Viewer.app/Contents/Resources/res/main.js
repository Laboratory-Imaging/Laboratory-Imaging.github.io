if (!HTMLScriptElement.supports?.("importmap")) {
    console.log("Browser does NOT support import maps.");
}
  

import * as LimImageView from '/res/gnr_express/LimImageView.js';

class ImageView extends LimImageView.LimImageView {
    constructor(...args) {
        super(...args);
    }
    
    get resoucePrefix() {
        return "/res/gnr_core_gui/"
    }

    loadTile(seqindex, reqpower, x, y, selchannel, selbinlayers, gains) {
        const url = new URL(`/api/v1/image_rgb_tile`, window.location.origin)
        url.searchParams.append("seqindex", seqindex);
        url.searchParams.append("reqpower", reqpower);
        url.searchParams.append("tilex", x);
        url.searchParams.append("tiley", y);
        url.searchParams.append("selchannels", selchannel);
        url.searchParams.append("selbinlayers", selbinlayers);
        url.searchParams.append("luts", gains);
        return url.toString();
    }
    
    async loadImageMetadata() {
        const response = await fetch(`/api/v1/image_metadata`);
        return await response.json();
    }

    async autoLuts(seqindex) {
        const url = new URL(`/api/v1/image_auto_luts`, window.location.origin)
        url.searchParams.append("seqindex", seqindex);        
        const response = await fetch(url.toString());
        return await response.json();
    }

    async loadVolumeInfo(seqindex, reqpower) {
        const url = new URL(`/api/v1/volume_info`, window.location.origin)
        url.searchParams.append("seqindex", seqindex);
        url.searchParams.append("reqpower", reqpower);
        const response = await fetch(url.toString());
        return await response.json();
    }
};

const imageView = new ImageView();
imageView.onzoomindexchanged = () => {
    zoomPicker.value = imageView.zoomIndex;
};

const lp = document.getElementById("load-progress");
imageView.onLoadProgressChanged = (value) => {
    lp.value = lp.value < 100 ? Math.max(lp.value, value) : value;
    lp.innerText = `${value}%`;
};

document.getElementById("viewport").appendChild(imageView.imageCanvasDomElement);
document.getElementById("pane").appendChild(imageView.navigatorDomElement);

const imageOpenButton = document.getElementById("open-image-button");
imageOpenButton.onclick = async () => {
    openFile(await window.pywebview.api.open_image_file());    
};

const openFile = (filename) => {
    if (!filename.length)
        return;

    imageView.clearFile();
    imageView.viewingMode = LimImageView.ViewingMode.imageView;
    imageView.clearCanvas();
    imageViewButton.ariaPressed = "true";
    volumeViewButton.ariaPressed = "false";

    imageView.loadFile().then(() => {
        const chNames = imageView.channelNames;
        if (1 < chNames.length && !imageView.is8bitRgb) {
            channelPicker.options = [{ text: "All", value: -1, selected: true }, ...imageView.channelNames.map((name, index) => ({ text: name, value: index }))];
            channelPicker.hidden = false;
        }
        else {
            channelPicker.hidden = true;
        }

        const binNames = imageView.binaryNames;
        if (binNames.length) {
            binaryPicker.options = binNames.map((name, index) => ({ text: name, value: index }))
            binaryPicker.hidden = false;
        }
        else {
            binaryPicker.hidden = true;
        }

        lutsSwitch.checked = false;

        const zooms = imageView.imageZoomSizes;
        if (zooms.length) {
            zoomPicker.options = zooms.map((item, index) => ({ text: `${item.z}%`, value: index }));
            zoomPicker.hidden = false;
            zoomPicker.value = imageView.zoomIndex;
            bestfitButton.hidden = false;                    
        }
        else {
            zoomPicker.hidden = true;
            bestfitButton.hidden = true;
        }

        imageViewButton.hidden = imageView.is3d ? false : true;
        volumeViewButton.hidden = imageView.is3d ? false : true;                
    });

    lutsSwitch.hidden = false;
    lutsSwitch.ariaChecked = "false";
    lutsButton.hidden = false;
    autoLutButton.hidden = false;
    infoButton.hidden = false;
    closeButton.hidden = false;
}

const imageViewButton = document.getElementById("image-view-mode-button");
imageViewButton.onclick =  (event) => {
    imageViewButton.ariaPressed = "true";
    volumeViewButton.ariaPressed = "false";
    zoomPicker.hidden = false;
    bestfitButton.hidden = false;
    imageView.viewingMode = LimImageView.ViewingMode.imageView;
};

const volumeViewButton = document.getElementById("volume-view-mode-button");
volumeViewButton.onclick = (event) => {
    volumeViewButton.ariaPressed = "true";
    imageViewButton.ariaPressed = "false";
    zoomPicker.hidden = true;
    bestfitButton.hidden = true;        
    imageView.viewingMode = LimImageView.ViewingMode.volumeView;        
};

const channelPicker = document.getElementById("channel-picker");
channelPicker.onchange = () => {
    imageView.channelIndex = channelPicker.value;
}

const binaryPicker = document.getElementById("binary-picker");
binaryPicker.onchange = () => {
    imageView.binaryIndexes = binaryPicker.value;
}

const lutsSwitch = document.getElementById("luts-switch");
lutsSwitch.onclick = () => {
    imageView.lutsEnabled = lutsSwitch.checked;
    if (imageView.lutsEnabled && (0 === imageView.channelGains.filter(item => 1.0 < item).length)) {
        autoLutButton?.autoContrast();
    }
}

const autoLutButton = document.getElementById("auto-lut-button");
autoLutButton.onclick = () => {
    autoLutButton?.autoContrast();
};

autoLutButton.autoContrast = async () => {
    const offsets_and_gains = await imageView.autoLuts(imageView.currentSeqIndex);
    imageView.channelGains = offsets_and_gains[1];
    imageView.lutsEnabled = true;
    lutsSwitch.checked = true;
    lutsButton?.lutsDialog?.updateUi?.();
};

const lutsButton = document.getElementById("luts-button");
lutsButton.onclick = async () => {
    if (lutsButton?.lutsDialog) {
        lutsButton?.lutsDialog?.close?.();
        return;
    }

    lutsButton.pressed = true;
    const win_rect = document.body.getBoundingClientRect();
    const dialog = lutsButton.lutsDialog = document.createElement("div");
    const dialog_width = Math.floor(Math.min(600, win_rect.width-20));
    const dialog_left = Math.floor((win_rect.width - dialog_width) / 3);
    dialog.id = "luts-dialog";
    dialog.style.width = dialog_width + "px";
    dialog.style.position = "fixed";
    dialog.style.top = "42px";
    dialog.style.left = dialog_left + "px";
    dialog.style.zIndex = 1;
    dialog.style.backgroundColor = "var(--color-window)";
    dialog.style.display = "grid";
    dialog.style.gridTemplateColumns = "max-content 1fr 5em 24px";
    dialog.style.gap = "8px";
    dialog.style.padding = "16px";
    dialog.style.borderRadius = "4px";
    dialog.style.boxShadow = "0px 8px 16px 0px rgba(0,0,0,0.2)";
    dialog.style.padding = "2em";

    dialog.updateUi = () => {
        for (let i = 0; i < imageView.channelGains.length; i++) {
            lutsButton.lutsDialog.sliders[i].value = Math.log2(imageView.channelGains[i]);                
            lutsButton.lutsDialog.numbers[i].value = imageView.channelGains[i].toFixed(3);
        }            
    };

    dialog.close = () => {
        lutsButton.pressed = false;
        document.body.removeChild(lutsButton.lutsDialog);
        lutsButton.lutsDialog = null;
        return;
    };

    dialog.sliders = [];
    dialog.numbers = [];
    const reset_svg = await fetch("/res/gnr_core_gui/close.svg").then(r => r.text());
    for (let i = 0; i < imageView.channelNames.length; i++) {
        const name = document.createElement("span");
        name.innerText = imageView.channelNames[i];
        name.style.alignSelf = "center";
        name.style.userSelect = "none";

        const color = imageView.channelColors[i];
        const r = Math.min(255, parseInt(color.slice(1, 3), 16) + 128).toString(16);
        const g = Math.min(255, parseInt(color.slice(3, 5), 16) + 128).toString(16);
        const b = Math.min(255, parseInt(color.slice(5, 7), 16) + 128).toString(16);

        dialog.appendChild(name);

        const slider = LimHtmlToNode(`<input type="range" value="${Math.log2(imageView.channelGains[i])}" min="0" max="8" step="any" list="gain-tick-values" style="accent-color: #${r}${g}${b}; user-select: none" />`);
        slider.name = `gain-slider-${i}`;
        slider.oninput = (e) => {
            const logval = parseFloat(e.target.value)
            const value = Math.pow(2, logval);
            if (shiftKeyState) {
                for (let j = 0; j < dialog.sliders.length; j++) {
                    if (j != i)
                        dialog.sliders[j].value = logval;
                    dialog.numbers[j].value = value.toFixed(3);
                }
            }
            else                
                dialog.numbers[i].value = value.toFixed(3);
        }
        slider.onmouseup = (e) => {
            const value = Math.pow(2, parseFloat(e.target.value));
            if (shiftKeyState) {
                imageView.channelGains = imageView.channelNames.map(() => value);
            }
            else
                imageView.setChannelGain(i, value);
            imageView.lutsEnabled = true;
            lutsSwitch.checked = true;                
        }
        dialog.sliders.push(slider);
        dialog.appendChild(slider);

        const number = LimHtmlToNode(`<input type="numeric" value="${imageView.channelGains[i].toFixed(3)}" style="text-align: right; padding: 0.3em"/>`);
        number.name = `gain-number-${i}`;
        number.oninput = (e) => {
            const value = parseFloat(e.target.value);
            sliders[i].value = Math.log2(value);
        }

        number.onblur = (e) => {
            const value = parseFloat(e.target.value);
            dialog.sliders[i].value = Math.log2(value);
            imageView.setChannelGain(i, value);
            imageView.lutsEnabled = true;
            lutsSwitch.checked = true;                
        }

        dialog.numbers.push(number);
        dialog.appendChild(number);        

        const reset = document.createElement("button");
        reset.name = `gain-reset-${i}`;
        reset.style.padding = "6px";
        reset.appendChild(LimToolbar.fixSvg(reset_svg, "12px", "12px"));
        reset.onclick = () => {
            if (shiftKeyState)
                imageView.channelGains = imageView.channelNames.map(() => 1.0);
            else
                imageView.setChannelGain(i, 1.0);                
            dialog.updateUi();
        }
        dialog.appendChild(reset);
    }

    const infoText = document.createElement("span");
    infoText.innerText = `Hold the SHIFT key to move all sliders at once.`;
    infoText.style.gridColumnStart = "span 3";
    infoText.style.justifySelf = "center";
    infoText.style.alignSelf = "center";
    infoText.style.userSelect = "none";
    dialog.appendChild(infoText);         

    document.body.appendChild(dialog);
};


const infoButton = document.getElementById("info-button");
infoButton.onclick = () => {
    window.pywebview.api.show_image_info();
};

const zoomPicker = document.getElementById("zoom-picker");
zoomPicker.onchange = () => {
    imageView.zoomIndex = zoomPicker.value;
}

const bestfitButton = document.getElementById("best-fit-button");
bestfitButton.onclick = () => {
    imageView.bestFit();
};

const helpButton = document.getElementById("help-button");

helpButton.onclick = () => {
    window.pywebview.api.show_help();
};

const closeButton = document.getElementById("close-button");
closeButton.onclick = () => {
    imageView.clearFile();

    imageViewButton.hidden = true;
    volumeViewButton.hidden = true;
    channelPicker.hidden = true;
    binaryPicker.hidden = true;
    lutsSwitch.hidden = true;
    lutsButton.hidden = true;
    autoLutButton.hidden = true;
    infoButton.hidden = true;
    zoomPicker.hidden = true;
    bestfitButton.hidden = true;
    closeButton.hidden = true;    
};

var shiftKeyState = false;
document.onkeydown = document.onkeyup = document.onclick = (e) => {
    shiftKeyState = e.shiftKey;
    if (e.key == "Escape") {
        lutsButton?.lutsDialog?.close?.();
        imageView.playingLoop = "";        
    }    
    else if (e.type === "keydown" && e.key === "o") {
        imageOpenButton.onclick();
    }    

    if (!imageView.valid) {
        return
    }

    if (e.type === "keydown" && e.key === "+") {
        if (imageView.viewingMode == LimImageView.ViewingMode.imageView)
            imageView.zoomIndex = imageView.zoomIndex + 1;
        e.stopPropagation();
    }    
    else if (e.type === "keydown" && e.key === "-") {
        if (imageView.viewingMode == LimImageView.ViewingMode.imageView)
            imageView.zoomIndex = imageView.zoomIndex - 1;
        e.stopPropagation();
    }
    else if (e.type === "keydown" && e.key === "/") {
        if (imageView.viewingMode == LimImageView.ViewingMode.imageView)
            bestfitButton.onclick();
        e.stopPropagation();
    }    
    else if (e.type === "keydown" && e.key === "ArrowLeft") {
        imageView.moveCurrentLoopIndex("t", -1);
    }
    else if (e.type === "keydown" && e.key === "Home") {
        imageView.moveCurrentLoopIndex("z", 0);
    }    
    else if (e.type === "keydown" && e.key === "ArrowUp") {
        imageView.moveCurrentLoopIndex("z", 1);
    }
    else if (e.type === "keydown" && e.key === "ArrowDown") {
        imageView.moveCurrentLoopIndex("z", -1);
    }
    else if (e.type === "keydown" && e.key === "PageUp") {
        imageView.moveCurrentLoopIndex("m", -1);
    }
    else if (e.type === "keydown" && e.key === "PageDown") {
        imageView.moveCurrentLoopIndex("m", 1);
    }
    else if (e.type === "keydown" && "0123456789".includes(e.key)) {
        const ch = "0123456789".indexOf(e.key);
        if (0 <= ch && ch <= imageView.channelNames.length) {
            channelPicker.value = imageView.channelIndex = ch - 1;
            
        }
    } 
    else if (e.type === "keydown" && e.key === "`") {
        channelPicker.value = imageView.channelIndex = -1;
    }
    else if (e.type === "keydown" && (e.key === "." || e.key === ",")) {
        imageView.showSingleChannelInMono = !imageView.showSingleChannelInMono;
    }    
    else if (e.type === "keydown" && e.key === "l" && !e.ctrlKey) {
        lutsSwitch.checked = !lutsSwitch.checked;
        lutsSwitch.onclick();
    }
    else if (e.type === "keydown" && e.key === "a") {
        autoLutButton.onclick();
        e.stopPropagation();
    }
    else if (e.type === "keydown" && e.key === "l" && e.ctrlKey) {
        lutsButton.onclick();
    }    
    else if (e.type === "keydown" && e.key === "i") {
        infoButton.onclick();
    }
};

const viewportSizeObserver = new ResizeObserver((entries) => {
    let w = 0, h = 0;
    for (const entry of entries) {
        w = Math.floor(entry.contentRect.width);
        h = Math.floor(entry.contentRect.height);
    }
    imageView.updateCanvasSize(w, h);
});

viewportSizeObserver.observe(document.getElementById("viewport"));

